# mood. — website

This folder is a ready-to-publish **GitHub Pages** site. Everything (images, fonts,
code) is baked into `index.html`, so there is nothing to build or install.

---

## Fastest way to go live (your own github.io address)

1. Sign in to GitHub. Click the **+** (top right) → **New repository**.
2. Name it **exactly** `YOURUSERNAME.github.io`
   (swap in your real username — e.g. `moodbrand.github.io`).
3. Set it to **Public** → **Create repository**.
4. On the new repo page click **uploading an existing file**.
5. Drag in **`index.html`** and **`.nojekyll`** from this folder → **Commit changes**.
6. Wait ~1 minute, then visit **https://YOURUSERNAME.github.io** 🎉

That address is yours — the site is live and shareable.

---

## Publishing inside an existing repo instead

1. Upload `index.html` + `.nojekyll` to the repo (any folder, but root is simplest).
2. Repo → **Settings** → **Pages**.
3. Under **Build and deployment**, Source = **Deploy from a branch**.
4. Branch = **main**, folder = **/ (root)** → **Save**.
5. Your link shows at the top of that Pages screen after ~1 min:
   `https://YOURUSERNAME.github.io/REPONAME/`

---

## Updating the site later

Re-export `index.html` (ask me), then upload it to the repo again to replace the old
one. GitHub Pages redeploys automatically in about a minute.

## Files in this folder

- **index.html** — the whole website in one file. This is the only file that matters.
- **.nojekyll** — tells GitHub to serve the file as-is (leave it in).
